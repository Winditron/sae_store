

</body>
<script src="<?php echo BASE_URL; ?>/public/js/app.js"></script>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo \Core\Config::get('app.appname'); ?></title>

    <base href="<?php echo \Core\Config::get('app.baseurl'); ?>">

    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>/public/css/styles.css" rel="stylesheet">

</head>

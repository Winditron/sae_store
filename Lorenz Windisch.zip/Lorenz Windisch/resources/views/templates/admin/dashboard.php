<div class="dashboard">
    <h2>Willkommen im Administratorbereich!</h2>
    <div class="tile-display">
                <div class="tile-list">
                    <div class="tile "><a class="navlink" href="<?php echo BASE_URL . "/admin/products"; ?>">Produkte</a></div>
                    <div class="tile "><a class="navlink" href="<?php echo BASE_URL . "/admin/users"; ?>">Benutzerkonten</a></div>
                    <div class="tile "><a class="navlink" href="<?php echo BASE_URL . "/admin/orders"; ?>">Bestellungen</a></div>
                </div>
    </div>
</div>

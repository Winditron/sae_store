<div class="dashboard">
    <h2>Willkommen im Kontobereich!</h2>
    <div class="tile-display">
        <div class="tile-list">
            <div class="tile "><a class="navlink" href="<?php echo BASE_URL . "/profile/edit"; ?>">Kontoeinstellungen</a></div>
            <div class="tile "><a class="navlink" href="<?php echo BASE_URL . "/profile/orders"; ?>">Alle Bestellungen</a></div>
        </div>
    </div>
</div>

<div class="alert alert-danger">
    <strong><?php echo $httpCode; ?>:</strong>
    <?php echo $message; ?>
</div>

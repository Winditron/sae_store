<div class="product-list">

<?php foreach ($products as $product) {
    require __DIR__ . "/../../partials/product/card.php";
}?>

</div>
<div class="login-window">
    <form action="<?php echo BASE_URL; ?>/login/finish" method="post" class="login-form">
        <?php require __DIR__ . "/../../partials/authentication/loginform.php";?>
    </form>
</div>
<?php

return [
    'host' => 'localhost', // bei euch vermutlich "localhost"
    'user' => 'root',
    'password' => '', // bei euch vermutlich ""
    'dbname' => 'greenroom',
    'port' => 3306,
    'socket' => null,
];
